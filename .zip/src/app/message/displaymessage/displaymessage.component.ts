import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-displaymessage',
  templateUrl: './displaymessage.component.html',
  styleUrls: ['./displaymessage.component.scss']
})
export class DisplaymessageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
